from enum import Enum, auto


class NullsPosition(Enum):
    first = auto()
    last = auto()